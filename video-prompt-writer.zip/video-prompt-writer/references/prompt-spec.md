# Video Prompt Specification (LTX-2.5 & General Video Models)

Detailed reference for writing video-generation prompts. Rooted in the official LTX-2.5 prompting guide (docs.ltx.io, LTX-2.5 Pro API by Runware) and the Replicate LTX 2.5 Fast parameter page; principles generalize to MiniMax H3, Seedance, Kling, Runway, etc.

## 1. The six layers (detailed)

Write as **one flowing present-tense paragraph**, not a keyword list. Each layer is a directive the model tries to hold.

| # | Layer | What to specify | Tips |
|---|-------|----------------|------|
| 1 | **Shot 镜头** | Shot scale / category (wide, medium, close-up, establishing) | Lead with the core shot before layering detail |
| 2 | **Scene 场景** | Lighting, color palette, surface textures, atmosphere | Establishes mood & tone |
| 3 | **Action 动作** | Core action as a natural sequence, beginning→end | Present tense; name beats in order so the model paces runtime |
| 4 | **Character 角色** | Age, hairstyle, clothing, distinguishing features | Emotion via physical cues ("shoulders drop, exhales") not labels ("relieved") |
| 5 | **Camera 运镜** | How & when camera moves; subject after movement | Keep camera motion and subject motion in separate clauses |
| 6 | **Audio 音频** | Ambient, music, speech/singing | Dialogue in quotes; specify language & accent |

**General best results:**
- Single flowing paragraph; present-tense verbs for action/movement.
- Match detail level to shot scale (close-ups need more surface detail).
- Describe camera movement relative to the subject.
- Aim for 4–8 descriptive sentences.
- Iterate freely — these models are designed for fast experimentation.

## 2. Authentic example prompts (from official guides)

**Single-shot, real-estate lifestyle (six layers complete):**
> A warm real-estate lifestyle scene, a wide shot easing into a medium. Late-afternoon sun pours through floor-to-ceiling windows into a modern open-plan living room with pale oak floors, a low linen sofa, and a scatter of green plants. A woman in a cream knit sweater walks slowly in from the hallway holding a mug, crosses to the window, and stops to look out over the city as the light catches the rising steam. The camera pushes in gently from the doorway and follows her toward the glass. Soft golden-hour light, a warm natural color grade, shallow depth of field, realistic materials and reflections. Gentle ambience: quiet footsteps on the wood floor, a faint city hum through the window, no music.

**Locked camera, motion from subject only:**
> A high-energy fitness scene, a medium shot on a locked, static camera. A lean boxer in black training gear works through a fast combination in a dim industrial gym, hard shafts of window light cutting through drifting chalk dust. She snaps out a jab and a cross, rolls her head under an imaginary counter, and resets her stance with her breath ragged. The camera never moves; every bit of motion is her footwork, her gloves, and the dust turning in the light. A moody high-contrast grade, deep shadows, crisp detail. The audio is her sharp exhale on each punch, the scuff of her shoes on the concrete, and a low industrial room tone, no music.

**Product close-up (macro + camera arc):**
> A macro commercial shot frames an unlabeled amber perfume bottle on polished black marble. A narrow beam of warm light travels slowly across the curved glass, revealing small droplets of condensation. The camera makes a controlled clockwise arc around the bottle while keeping the metallic cap in sharp focus. As the camera reaches a three-quarter front angle, a single droplet runs down the glass and the light settles into a soft golden rim. The shot ends in a clean hero composition with negative space on the left for title. A low ambient tone plays beneath the quiet sound of the droplet touching the marble.

## 3. Character-consistency anchor

LTX-2.5 holds continuity better than predecessors, but identity must still be directed explicitly.

**Formula:** `Name + age range + facial traits + hair + fixed wardrobe + distinctive accessory + voice`

**Example:**
> Maya, a woman in her early thirties with an oval face, warm brown skin, shoulder-length black curls, a cream linen jacket, and a small gold pendant. She speaks in a calm, low voice.

**Rules:**
- Subjective words ("beautiful", "cinematic-looking") cannot preserve identity — use concrete traits.
- Across a cut, the model has no memory of the exact face it drew a second earlier. **Repeat the key anchor tokens verbatim** each time the character reappears ("the same woman with shoulder-length black curls, the cream linen jacket, the small gold pendant"), rather than writing "her face".
- Anchor the tag on something concrete and repeatable (wardrobe, color, object), not a name the model cannot see.

## 4. Multi-shot (native multishot) rules

LTX-2.5 Pro can cut between **2–4 shots in one generation**, holding character/lighting/voice across cuts. Write the whole sequence as one chronological paragraph; skip numbered beats unless you also describe the cut in prose.

**At every cut, state four things:**
1. **Name the transition** — "A hard cut transitions to" / "a match cut connects" / "the image dissolves into". Tells the model an edit happens, not a camera move.
2. **Re-establish the shot** — new scale, angle, who/what is in frame, lighting if changed. The model does not carry prior framing forward.
3. **Keep identity consistent** — reuse the same visual tag for a recurring person/object.
4. **State the audio** — music/ambience/dialogue continues, softens, or changes across the cut.

**Best practices:**
- 2–4 shots per 8–10s clip. Past four shots, each gets too little time and identity/continuity slip.
- Give each shot a job and build in order (wide→close, or establish→detail→reaction). Three unrelated wides read as stapled clips.
- Re-identify the subject every time it reappears.

## 5. What works well / what to avoid

**Works well:** cinematic compositions (wide/medium/close-up with thoughtful lighting, shallow DoF, natural motion); emotive human moments (single-subject, subtle gestures, facial nuance); atmosphere & setting (fog, mist, golden-hour, rain, reflections, ambient textures); clear camera language ("slow dolly in", "handheld tracking"); stylized aesthetics (painterly, noir, analog film, fashion editorial, pixelated); lighting & mood control (backlighting, color palettes, rim light, flickering lamps); multilingual voice (characters talk/sing in multiple languages).

**Avoid:**
- **Internal emotional states** — use visual cues instead of "sad"/"confused".
- **Text and logos** — on-screen text spelling & frame-to-frame consistency not guaranteed; keep text short, verify across clip, composite critical titles/logos in post.
- **Complex physics / chaotic motion** — can smear; plausible everyday motion (walk, dance) is fine.
- **Overloaded scenes** — too many characters/actions reduce clarity.
- **Conflicting lighting** — mixed light logic confuses scene interpretation.
- **Overcomplicated prompts** — start simple, layer complexity gradually.

## 6. Parameter / config reference (LTX 2.5 Fast via Replicate)

| Param | Meaning | Values / Default |
|-------|---------|------------------|
| `prompt` | Video description (required) | text |
| `image` | First frame for image-to-video | image / none |
| `last_frame_image` | End frame for interpolation (requires `image`) | image / none |
| `resolution` | Output resolution | 720p / **1080p** / 2k / 4k |
| `duration` | Length in seconds | 2/3/4/5/6/8/10/12/14/16/18/20, **default 6** |
| `aspect_ratio` | Frame ratio | 16:9 (landscape) / 9:16 (portrait) |
| `fps` | Frame rate | 24 / **25** / 48 / 50 |
| `generate_audio` | Synchronized audio | **true** / false |

**Constraints:**
- Durations > 10s only at 720p/1080p with 24/25 fps. At 48/50 fps the max duration is 10s.
- Output: MP4 with synchronized audio (when `generate_audio` enabled).
- Technical: `num_frames % 8 == 1`; dimensions must divide by 32.

## 7. Dub-It (speech replacement) IC-LoRA template

For replacing dialogue in an existing video:
> `[Speaker] is speaking [Language/Accent], saying: "[Dialogue]"`

Rules: provide full dialogue text (model follows prompt content, does not translate); use native script (Cyrillic for Russian, Chinese characters for Mandarin); single speaker only (beta does not distinguish multiple speakers). Match audio length — keep prompt near the original dialogue's timing/syllable length; slightly longer is better than too short.

## 8. Risk / caveat notes

- LTX-2.5 "open weights" is governed by the LTX-2.x Community License (not OSI). Entities with ≥ $10M annual revenue need a paid license; derivative works (incl. models trained on its outputs, distilled versions) fall under the same license; military/weapons use prohibited; synthetic-media disclosure required.
- Speed/quality figures (6.8s/10s, blind-test win rates) are vendor-reported; independent benchmarks (e.g., Artificial Analysis) had not listed LTX-2.5 at release. Validate with the user's own workload.
- Minimum VRAM ~16GB for distilled/local runs; full 22B dev model needs more. int8 / NVFP4 / fp8 / CPU offload available for smaller cards.
