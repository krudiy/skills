# Video Prompt Terminology Bank

Drop these terms directly into prompts to control camera, style, lighting, atmosphere, voice, and pacing. Sourced from the official LTX prompting guide's "Helpful Terms" list.

## Camera language (运镜)
- follows / tracks / pans across / circles around / tilts upward / pushes in / pulls back
- overhead view / handheld movement / over-the-shoulder / wide establishing shot / static frame
- tracking from behind / locked camera / dolly in / dolly out

## Cinematic / style (风格)
- period drama / film noir / fantasy / epic space opera / thriller / modern romance / experimental film / arthouse / documentary
- stop-motion / 2D animation / 3D animation / claymation / hand-drawn / stylized / comic book
- cyberpunk / 8-bit pixel / surreal / minimalist / painterly / illustrated

## Lighting & mood (光影)
- flickering candles / neon glow / natural sunlight / dramatic shadows
- backlighting / rim light / color palettes (vibrant / muted / monochromatic / high contrast)
- golden-hour / soft key light / hard window light / volumetric light

## Visual details (视觉细节)
- rough stone / smooth metal / worn fabric / glossy surfaces
- film grain / lens flares / pixelated edges / jittery stop-motion

## Atmosphere (氛围)
- fog / mist / rain / dust / smoke / particles / reflections / ambient textures

## Sound & voice (声音)
- Ambient: coffeeshop noise / wind and rain / forest ambience with birds
- Dialogue style: energetic announcer / resonant voice with gravitas / distorted radio-style / robotic monotone / childlike curiosity
- Volume: whisper / mutter / shout / scream

## Scale & pacing (尺度与节奏)
- Scale: expansive / epic / intimate / claustrophobic
- Pacing: slow motion / time-lapse / rapid cuts / lingering shot / continuous shot / freeze-frame / fade-in / fade-out / seamless transition / sudden stop

## Technical style markers (技术质感)
- shallow depth of field / anamorphic / macro / wide-angle distortion / motion blur / depth of field

## Chinese equivalents (中文对应，便于中文提示词)
- 运镜：跟随 / 平移 / 环绕 / 上摇 / 推近 / 拉远 / 俯拍 / 手持 / 过肩 / 远景建立镜头 / 固定机位 / 锁定镜头 / 从背后跟拍
- 风格：年代剧 / 黑色电影 / 奇幻 / 太空歌剧 / 惊悚 / 现代爱情 / 实验影像 / 艺术电影 / 纪录片 / 定格动画 / 赛博朋克 / 像素 / 超现实 / 极简 / 绘画感
- 光影：闪烁烛光 / 霓虹辉光 / 自然日光 / 戏剧性阴影 / 逆光 / 轮廓光 / 黄金时刻
- 氛围：雾 / 雨 / 尘 / 烟 / 粒子 / 倒影
- 节奏：慢动作 / 延时 / 快速剪辑 / 长镜头 / 定格 / 淡入 / 无缝转场
