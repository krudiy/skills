---
name: video-prompt-writer
description: This skill should be used when the user wants to write, refine, structure, or troubleshoot prompts for AI video generation models (text-to-video / image-to-video), including LTX-2.5, MiniMax H3, Seedance, Kling, Runway, and similar. It codifies the six-layer prompt structure (shot, scene, action, character, camera, audio), character-consistency anchors, native multi-shot sequencing syntax, a terminology bank, and reusable Chinese/English templates, producing production-ready prompts. Trigger when the user asks for video prompts, "提示词", cinematic shot scripting, character-consistent or multi-shot video generation prompts, or references LTX-2.5 / video model prompt specs.
---

# Video Prompt Writer

Write structured, production-ready prompts for AI video generation models. The method is rooted in the official LTX-2.5 prompting guide (docs.ltx.io, LTX-2.5 Pro API) and generalizes to other text-to-video / image-to-video models.

## When to use

- User asks to write or improve a prompt for generating video (any model).
- User references LTX-2.5, MiniMax H3, Seedance, Kling, Runway, or "视频提示词 / 提示词撰写".
- User needs character-consistent, multi-shot, product-ad, or cinematic video prompts.
- User supplies a rough idea and wants it turned into a model-ready prompt.

## Core principle: the six-layer structure

Every strong video prompt separates six concerns. Write them as **one flowing paragraph in the present tense**, not a bullet list. Each layer is a directive the model tries to hold; naming all six keeps decisions with the author instead of the model's defaults.

1. **Shot (镜头)** — Cinematography term + shot scale (wide / medium / close-up). Lead with the core shot before layering detail.
2. **Scene (场景)** — Lighting, color palette, surface textures, atmosphere. Set mood and tone.
3. **Action (动作)** — Core action as a natural sequence flowing beginning to end, present tense.
4. **Character (角色)** — Age, hairstyle, clothing, distinguishing features. Express emotion via physical cues, NOT abstract labels.
5. **Camera (运镜)** — How and when the camera moves; describe subject appearance after the movement.
6. **Audio (音频)** — Ambient sound, music, speech/singing. Put spoken dialogue in quotes; specify language/accent.

## Workflow

1. **Clarify intent** (ask only if genuinely missing): target model, single-shot vs multi-shot, subject/product, visual style, duration & aspect ratio. If the user gave enough, skip questioning and proceed.
2. **Draft the six layers.** Separate Shot / Scene / Action / Character / Camera / Audio. Keep one coherent light logic per shot. Match detail density to shot scale — close-ups must name every material or the model invents it.
3. **Add a character anchor** when continuity matters: `Name + age range + facial traits + hair + fixed wardrobe + distinctive accessory + voice`. Repeat the anchor's key tokens verbatim each time the character reappears across cuts.
4. **For multi-shot**, write the whole sequence as one chronological paragraph and, at every cut, state four things: (a) name the transition ("A hard cut transitions to" / "the image dissolves into"), (b) re-establish the new shot scale/angle/subject/lighting, (c) keep identity consistent by reusing the visual tag, (d) state whether audio continues/softens/changes. Keep 2–4 shots per 8–10s clip.
5. **Validate against the do/don't list** (see references/prompt-spec.md). Key avoids: internal emotional labels (use visual cues), on-screen text/LOGOS (unreliable — composite in post), chaotic motion (smears), overloaded scenes, conflicting lighting, overcomplicated prompts.
6. **Assemble.** Either write the paragraph directly, or run `scripts/build_prompt.py` to assemble a structured input into a flowing prompt (supports single-shot and multi-shot, `--lang zh|en`).
7. **Iterate one variable at a time.** Change subject / product / location / lighting / motion / sound while preserving structure.

## Bundled resources

- `references/prompt-spec.md` — Full specification: detailed six-layer guidance, authentic example prompts, character-anchor formula, multi-shot rules, parameter/config tables (LTX 2.5 Fast / Replicate), and risk notes.
- `references/terminology.md` — Camera, style, lighting, atmosphere, voice, pacing word banks to drop into prompts.
- `assets/templates.md` — Copy-paste Chinese + English templates for single-shot narrative, product close-up, and multi-shot sequences.
- `scripts/build_prompt.py` — Deterministic prompt assembler from structured JSON/YAML input.

## Notes

- LTX-2.5 bundles an optional **Prompt Enhancer** that expands short prompts into detailed instructions, so short prompts are acceptable for that model — but explicit six-layer prompts give the most control.
- Treat model-specific speed/quality claims as vendor-reported; verify with the user's own hardware and workload.
