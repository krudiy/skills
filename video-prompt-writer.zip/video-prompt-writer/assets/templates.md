# Reusable Video Prompt Templates

Copy, replace the bracketed `[...]` fields, and keep the six-layer structure. Iterate one variable at a time. Write the final prompt as one flowing present-tense paragraph (not a list).

---

## Template A — Single-shot narrative ( lifestyle / real-estate / general )

**中文**
```
[氛围形容词]的[场景类型]场景，[景别，如：从远景缓推到中景]。
[光照与色彩，如：午后阳光透过落地窗洒入…浅色橡木地板、布艺沙发、绿植]。
[角色描述，如：一位穿米色针织衫的女子] [动作序列·现在时，如：从走廊走入、端着杯子、走到窗前驻足远眺，光捕捉到升腾的热气]。
[运镜，如：镜头从门口轻轻推近并跟随她走向玻璃]。
[影调，如：柔和黄金时刻光、温暖自然调色、浅景深、真实材质与反射]。
[音频，如：木地板上安静的脚步声、窗外微弱的城市嗡鸣，无音乐]。
```

**English**
```
A [mood] [scene type] scene, [shot scale, e.g. a wide shot easing into a medium].
[Lighting & color, e.g. late-afternoon sun pours through floor-to-ceiling windows into…pale oak floors, a linen sofa, green plants].
[A character description] [action sequence in present tense, e.g. walks in from the hallway holding a mug, crosses to the window, and stops to look out as the light catches the rising steam].
[Camera, e.g. the camera pushes in gently from the doorway and follows her toward the glass].
[Grade, e.g. soft golden-hour light, a warm natural color grade, shallow depth of field, realistic materials and reflections].
[Audio, e.g. quiet footsteps on the wood floor, a faint city hum through the window, no music].
```

---

## Template B — Product close-up / commercial ( macro + camera move )

**中文**
```
一个[产品]的[景别]镜头，框住[产品外观描述]置于[材质/背景]。
一束[光质]缓慢扫过[曲面/材质]，显现出[细节，如凝结水珠]。
[运镜，如：镜头以受控顺时针弧线环绕产品，保持金属盖锐焦]。
当镜头到达[角度]时，[细节动作，如一滴水沿玻璃滑落，光沉淀为柔和金边]。
镜头结束于[收尾构图，如：左侧留白用于标题]的干净主视觉。
[音频，如：低沉环境音伴随水珠轻触材质的细微声响]。
```

**English**
```
A [shot scale] of [product], framing [product appearance] on [material/background].
A [light quality] travels slowly across [surface], revealing [detail, e.g. small droplets of condensation].
[Camera, e.g. the camera makes a controlled clockwise arc around the product while keeping the cap in sharp focus].
As the camera reaches [angle], [detail action, e.g. a single droplet runs down the glass and the light settles into a soft golden rim].
The shot ends in a clean hero composition with [negative space note] for title.
[Audio, e.g. a low ambient tone beneath the quiet sound of the droplet touching the surface].
```

---

## Template C — Multi-shot ( 2–4 cuts, hold character / lighting / audio )

**中文**
```
[景别]建立[环境，如：安静的酒店大堂，傍晚]。
[角色锚点全句，如：Elena，三十出头、椭圆脸、橄榄色皮肤、深棕波浪长发及肩、酒红定制大衣、小银环耳饰]从旋转门进入。
[光照与配乐，如：柔和琥珀光映在大理石地面，背景钢琴乐]。
[转场命名]切到[新景别]的[角色，重复锚点关键词]，她在[相同光照]下走向前台。
[运镜，如：镜头以她的步速后拉，钢琴旋律跨切延续]。
[转场命名]切到[角色面部特写]，她的[锚点特征]依旧可见。
```

**English**
```
[A shot scale] establishes [environment, e.g. a quiet hotel lobby in the early evening].
[Full character anchor, e.g. Elena, a woman in her early thirties with an oval face, olive skin, shoulder-length dark brown waves, a tailored burgundy coat, and small silver hoop earrings] enters through the revolving door.
[Lighting & score, e.g. soft amber light reflects across the marble floor while restrained piano music plays].
[A transition name] cuts to [new shot scale] of [character, repeat anchor keywords]; she walks toward the reception desk under the same soft amber lighting.
[Camera, e.g. the camera tracks backward at her pace while the piano melody continues across the cut].
[A transition name] cuts to a close-up of [character's] face; her [anchor features] remain visible.
```

---

## Character anchor block (reuse across shots)

**中文**
```
[名字]，[年龄区间]、[脸型]、[肤色]、[发型长度卷直]、[固定衣装]、[辨识配饰]，说话声音[音色描述]。
```
**English**
```
[Name], a [age range] with [face shape], [skin tone], [hair], [fixed wardrobe], and [distinctive accessory]. She/he speaks in a [voice description].
```

> Across every cut, repeat the anchor's concrete tokens verbatim (wardrobe color, hair, accessory) — do not just write "her face".
