#!/usr/bin/env python3
"""
build_prompt.py — Assemble a structured video-generation prompt following the
six-layer method (Shot / Scene / Action / Character / Camera / Audio).

Supports single-shot and native multi-shot (2-4 cuts) output, in English or
Chinese. Intended as a deterministic helper for the video-prompt-writer skill.

Usage
-----
Single-shot via flags:
    python build_prompt.py --lang en \
        --shot "a wide shot easing into a medium" \
        --scene "late-afternoon sun through floor-to-ceiling windows into a modern living room" \
        --character "A woman in a cream knit sweater" \
        --action "walks in from the hallway holding a mug, crosses to the window, and stops to look out" \
        --camera "the camera pushes in gently from the doorway and follows her" \
        --audio "quiet footsteps on the wood floor, a faint city hum, no music"

Single / multi-shot via JSON file:
    python build_prompt.py --input prompt.json --lang zh

JSON shape (single):
    {"shot": "...", "scene": "...", "character": "...", "action": "...",
     "camera": "...", "style": "...", "audio": "..."}

JSON shape (multi-shot):
    {"intro": "...",  # optional establishing text
     "shots": [
        {"shot":"...","scene":"...","character":"...","action":"...",
         "camera":"...","style":"...","audio":"..."},
        {"transition":"A hard cut transitions to",
         "shot":"...","scene":"...","character":"...","action":"...",
         "camera":"...","style":"...","audio":"..."}
     ]}

The script only joins the fields you provide; empty fields are skipped.
"""

import argparse
import json
import sys


def _join(segments, lang):
    """Join non-empty phrase segments into one flowing paragraph."""
    segs = [s.strip() for s in segments if s and s.strip()]
    if not segs:
        return ""
    if lang == "zh":
        # Strip trailing Chinese full stops to avoid "。。" doubling.
        segs = [s.rstrip("。") for s in segs]
        text = "。".join(segs)
        if not text.endswith("。"):
            text += "。"
        return text
    # English: strip trailing period, capitalize, re-add ". "
    out = []
    for s in segs:
        s = s.rstrip(".").strip()
        if s and s[0].islower():
            s = s[0].upper() + s[1:]
        if s:
            out.append(s + ".")
    return " ".join(out)


def build_single(d, lang):
    character = d.get("character", "").strip()
    action = d.get("action", "").strip()
    # Combine character + action into one sentence (role then motion).
    char_action = f"{character} {action}".strip() if (character and action) else (character or action)
    segments = [
        d.get("shot", "").strip(),
        d.get("scene", "").strip(),
        char_action,
        d.get("camera", "").strip(),
        d.get("style", "").strip(),
        d.get("audio", "").strip(),
    ]
    return _join(segments, lang)


def build_multi(d, lang):
    intro = d.get("intro", "").strip()
    shots = d.get("shots", [])
    parts = []
    if intro:
        parts.append(intro)
    for i, shot in enumerate(shots):
        transition = shot.get("transition", "").strip()
        seg = build_single(shot, lang)
        if transition:
            # Prepend transition as its own clause.
            if lang == "zh":
                seg = f"{transition}，{seg}"
            else:
                seg = f"{transition}, {seg[0].lower()}{seg[1:]}" if seg else transition
        parts.append(seg)
    return _join(parts, lang)


def main():
    ap = argparse.ArgumentParser(description="Assemble a six-layer video prompt.")
    ap.add_argument("--input", help="Path to JSON file (single or multi-shot).")
    ap.add_argument("--lang", choices=["en", "zh"], default="en", help="Output language.")
    ap.add_argument("--shot")
    ap.add_argument("--scene")
    ap.add_argument("--character")
    ap.add_argument("--action")
    ap.add_argument("--camera")
    ap.add_argument("--style")
    ap.add_argument("--audio")
    ap.add_argument("--out", help="Optional path to write the result instead of stdout.")
    args = ap.parse_args()

    if args.input:
        try:
            with open(args.input, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:  # noqa: BLE001
            sys.stderr.write(f"Failed to read JSON input: {e}\n")
            sys.exit(1)
        if "shots" in data:
            result = build_multi(data, args.lang)
        else:
            result = build_single(data, args.lang)
    else:
        result = build_single({
            "shot": args.shot or "",
            "scene": args.scene or "",
            "character": args.character or "",
            "action": args.action or "",
            "camera": args.camera or "",
            "style": args.style or "",
            "audio": args.audio or "",
        }, args.lang)

    if not result.strip():
        sys.stderr.write("No prompt content provided.\n")
        sys.exit(1)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(result)
        print(f"Prompt written to {args.out}")
    else:
        print(result)


if __name__ == "__main__":
    main()
