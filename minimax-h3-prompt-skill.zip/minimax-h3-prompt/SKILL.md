---
name: minimax-h3-prompt
description: Write and rewrite prompts for MiniMax H3 (Hailuo H3) omni-modal video generation. Use when the user asks for H3 prompts, MiniMax H3 / Hailuo H3 prompt writing, T2VA I2VA FL2VA Ref2VA prompting, multimodal reference video prompts, or structured audiovisual prompts for MiniMax H3.
---

# MiniMax H3 Prompt Writing Skill

Write production-ready prompts for **MiniMax H3** (also called Hailuo H3), the omni-modal video model that generates up to 15s 2K video with native stereo audio from text, images, video, and audio.

H3 has two main prompt regimes:

1. **Base modes** (T2VA / I2VA / FL2VA / L2VA) — text ± first/last frame images
2. **Full-reference mode** (Ref2VA) — text + multi-modal references (images ≤9, videos ≤3, audio ≤3, total files ≤12)

Always produce the **final structured English prompt** that H3-Base expects. When the user gives a rough idea or natural-language brief, expand it into the full structured format below. Prefer the official field names and conventions exactly.

## Model Constraints (always respect)

- Duration: 4–15 seconds (state target duration if known)
- Aspect ratios: 21:9, 16:9, 4:3, 1:1, 3:4, 9:16 (and similar)
- Output: 24 FPS, native stereo audio (32 kHz)
- Dialogue languages with stable support: Arabic, Chinese, English, French, German, Italian, Japanese, Korean, Portuguese, Russian, Spanish
- Audio cannot be the sole input; must accompany image or video when used as reference
- On-screen text and dialogue content preserve original language/punctuation verbatim

## Core Writing Principles

1. **Describe visible change over time.** H3 responds best to sequences of observable actions, not static noun piles or pure mood words.
2. **Language is the bridge.** Express reference/editing relationships in natural language (“use the camera movement from Video 1”, “the character in Image 2 sings matching Audio 3”).
3. **Timeline first.** Build the audiovisual description chronologically with explicit shots and cut times.
4. **Separate diegetic vs non-diegetic sound.** Dialogue, singing, on-screen instruments, and physical action sounds belong in the multimodal description; audience-only background music goes in `non_diegetic_music`.
5. **Be concrete.** Style, composition, subject appearance, lighting, camera motion (type + amplitude + speed), and sound must be explicit and consistent across the clip.
6. Write all structural fields in **English**. Preserve original language only inside `<d>...</d>` dialogue/lyrics and for on-screen text in quotation marks.

## Decision Flow

```
User request
├── Only text (no images/videos/audio) → T2VA
├── One image as first frame → I2VA
├── Two images as first + last frame → FL2VA
├── One image as last frame only → L2VA
└── Any combination of reference images/videos/audio (or editing/continuation) → Ref2VA (full-reference format)
```

If the user supplies rough natural language and media, choose the matching mode and expand into the structured prompt. When using official API with H3-Context-IR, the structured prompt is what Context-IR produces; for local H3-Base or direct structured prompting, output the structured form directly.

## Base Modes Format (T2VA / I2VA / FL2VA / L2VA)

### Instruction line (first line, then blank line)

- **T2VA**: no instruction line — start directly with the three core fields.
- **I2VA**:
  ```
  For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.
  ```
- **FL2VA**:
  ```
  How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.
  ```
  (`N` = final shot index, `S.SS` = exact duration to two decimals)
- **L2VA**:
  ```
  How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.
  ```

### Three core fields (required)

```
integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: ...
```

#### integrated_multimodal_description

- Chronological timeline of visuals + actions + shots + speakers + dialogue/singing + diegetic sound.
- Start `[Shot 1]` with style + initial composition (Cinematic, live-action, 2D-animated, 3D CG, claymation, watercolor, vintage film, etc.).
- Later shots: `[Shot 2] At 00:03.500, the camera cuts to...` (strictly increasing times inside duration).
- Prefer camera motion over unnecessary cuts when only distance/angle changes.
- Camera motion formula: **type + amplitude + speed** written as natural action:
  - Types: Zoom In/Out, Push In/Pull Out, Pan Left/Right, Truck Left/Right, Tilt Up/Down, Pedestal Up/Down, Arc Shot, Tracking Shot, Static Shot, Shake Slightly/Strongly, POV, Roll Clockwise/Counterclockwise
  - Amplitude: with small/large amplitude (omit medium)
  - Speed: at slow/fast speed (omit normal)
  - Example: `The camera pushes in with small amplitude at slow speed toward the letter.`

#### Speakers & dialogue

- Stable IDs: `(S1)`, `(S2)`, `(S1,S2)` for simultaneous speakers.
- First appearance: give identity cues (age, gender, voice quality, on/off-screen).
- Format:
  ```
  The young woman with a quiet, breathy voice (S1) says: <d>[English] I get off at the next station.</d>
  ```
- Voiceover: `says in an off-screen voiceover: <d>[Lang] ...</d> while his/her lips remain completely closed.`
- Cross-cut continuity: use `<scenetrans>` and phrases such as “continues seamlessly across the cut”.
- Truncation at end: `<cutoff>`.
- Inside `<d>`: language tag + exact user-provided words/punctuation only. Never translate or rewrite dialogue content.

#### On-screen text

- Put visible text in English double quotes, preserve original characters:
  ```
  A red neon sign reading "营业中" glows above the doorway.
  ```

#### overall_soundscape

- 1–4 English sentences covering ambient + physical + non-verbal human sounds across the whole video.
- Do **not** repeat dialogue, singing, or diegetic music here.
- Use `N/A` only if the user demands complete silence.

#### non_diegetic_music

- 1–3 English sentences describing audience-only background music (instrumentation, tempo, dynamics).
- Avoid abstract mood words (“emotional”, “sad”).
- Diegetic music (radio, phone, instruments characters hear) goes in the multimodal description.
- Use `N/A` when none.

### Keyframe path guidance

- **I2VA**: first-frame anchor → action onset → continuous development → result/reaction. Keep identity, clothing, colors, props consistent.
- **FL2VA**: first-frame state → observable intermediate changes → progressively narrowing differences → last-frame state. Prefer single continuous shot unless multi-shot is requested.
- **L2VA**: plausible preceding state → explicit transition path → gradual convergence in final shot → land on last frame.

## Full-Reference Mode Format (Ref2VA)

Output **six sections in this exact order**, all in English (except dialogue/lyrics and on-screen text):

```
subject_definitions:
...

summary:
...

retention_analysis:
...

detailed_description:
...

overall_soundscape:
...

non_diegetic_music:
...
```

### subject_definitions

Define every tracked reference with stable labels:

| Label | Use for |
|-------|---------|
| `<Subject N>` | Reusable visible content (person, object, scene, style, pose, motion…) |
| `<Picture N>` | Image that acts as concrete frame / keyframe / composition anchor |
| `<Video N>` | Whole-video source for edit, continuation, or temporal structure |
| `<Audio N>` | Audio asset or synced track (copy, timbre, rhythm, lyrics…) |

Examples:

```
<Subject 1> is the young woman in <Picture 1>, with long dark hair, a blue cardigan, and a thin silver necklace.
<Subject 1> is the woman whose appearance comes from <Picture 1> and whose walking motion comes from <Video 1>.
<Video 1> is the source video for the target video edit.
<Audio 1> is the voice-timbre reference for <Subject 1> (S1).
```

Number each category independently. One asset can supply multiple subjects; cite source inside the definition when needed.

### summary

One short paragraph starting with a square-bracketed task-type prefix (combine with `+` when multiple apply, no repeats):

- `keyframe completion`
- `reference generation`
- `video editing`
- `video continuation`
- `audio reuse`
- `audio reference`

Examples:

```
[reference generation] ...
[video editing + audio reuse] The target video is an edited version of <Video 1>. ...
[video continuation + keyframe completion] ...
```

Use only previously defined labels. For pure video editing start after the prefix with “The target video is an edited version of <Video 1>.”

### retention_analysis

One line per label describing preservation:

**Visual markers**: `fully_preserved` | `partially_preserved` | `attribute_transfer` | `weak_reference`

**Audio markers**: `fully_copy` | `partially_copy` | `reference` | `weak_reference`

```
<Subject 1> (appears in [Shot 1], [Shot 3]): fully_preserved - appearance and clothing remain identical.
<Audio 1>: fully_copy - reused 1:1 as the complete final audio track.
```

### detailed_description

Timeline body (same shot / camera / speaker / dialogue conventions as base mode). Be highly explicit about composition, appearance, lighting, actions, camera, sound, and exact points where referenced content appears or takes effect. Do not reduce to a plot summary.

### overall_soundscape & non_diegetic_music

Same rules as base modes.

## Quick Checklist Before Output

- [ ] Correct mode selected and instruction line (if any) present
- [ ] All required fields present and in order
- [ ] Shots numbered, cut times strictly increasing and inside duration
- [ ] Camera motions written as natural actions with type/amplitude/speed when relevant
- [ ] Speaker IDs stable; dialogue inside `<d>[Lang] ...</d>` with original wording
- [ ] On-screen text in quotes, original language kept
- [ ] Diegetic vs non-diegetic sound correctly separated
- [ ] Reference labels consistent across all sections (Ref2VA)
- [ ] English structural text; no translation of user dialogue or visible text
- [ ] Visible change / progression clearly described

## Common Pitfalls to Avoid

- Vague mood-only prompts (“cinematic, epic, emotional”) without concrete actions or camera path
- Stacking camera labels at the end of a sentence instead of embedding them as actions
- Translating or rewriting dialogue inside `<d>`
- Putting non-diegetic music description into `overall_soundscape` or vice versa
- Using audio as sole input
- Inconsistent subject identity, clothing, or spatial relations across shots
- Missing first-frame / last-frame alignment instruction for I2VA/FL2VA/L2VA
- Creating standalone `<Picture N>` when the image only defines a subject (put it inside `<Subject N>` instead)

## When User Gives Only a Rough Idea

1. Infer the most suitable mode.
2. Expand into full structured prompt, filling reasonable concrete details that stay faithful to user intent (style, lighting, camera, ambient sound).
3. If duration/aspect ratio not specified, assume a sensible default (e.g. 8–10s, 16:9) and note it.
4. If the user later wants to feed the result into H3-Context-IR, the structured English prompt is already the preferred target form.

For extended examples and edge cases, see:

- `references/base-prompt-examples.md`
- `references/ref-prompt-examples.md`
