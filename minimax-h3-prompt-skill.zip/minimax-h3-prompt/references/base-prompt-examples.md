# Base Mode Prompt Examples (T2VA / I2VA / FL2VA / L2VA)

## Example 1 — T2VA (text only)

```
integrated_multimodal_description: [Shot 1] Live-action, cinematic, a medium-wide shot frames a baker opening the shutters of a small street bakery before sunrise. The camera pushes in with small amplitude at slow speed as the middle-aged baker with a calm, slightly raspy voice (S1) places a fresh loaf on the wooden counter and says: <d>[English] First batch of the morning.</d> [Shot 2] At 00:05.000, the camera cuts to a close-up of steam rising from the sliced bread while the baker's final words carry over from the previous shot.

overall_soundscape: Wooden shutters scrape open over a quiet street as trays clink softly inside the bakery. The doorbell rings once, followed by light footsteps and the crisp sound of bread being sliced.

non_diegetic_music: A soft acoustic-guitar pattern at a moderate tempo, joined by sparse upright-bass notes and a gentle fade at the end.
```

## Example 2 — I2VA (first-frame image)

Instruction line first:

```
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] This is a live-action, cinematic shot with a shallow depth of field. The camera holds a perfectly static shot throughout the entire eight-second duration, capturing a cozy family gathering in a traditional Japanese dining room. The scene opens with a large, intricately patterned blue and white ceramic bowl of ramen in the immediate foreground, rendered in crisp, sharp focus... [continue chronological development, focus pull, family interaction, rising steam]

overall_soundscape: The soundscape begins with a quiet room tone mixed with the faint, airy rustle of the thick steam... [physical dinner sounds become dominant]

non_diegetic_music: A gentle, heartwarming acoustic guitar melody plays softly in the background, accompanied by the subtle, resonant notes of a traditional Japanese koto...
```

## Example 3 — FL2VA (first + last frame)

```
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 1) aligns with the 08.00-second mark of the target video.

integrated_multimodal_description: [Shot 1] Live-action, cinematic. The camera begins on the exact composition of Picture 1: a young woman standing at a rain-soaked bus stop under a yellow umbrella... The camera slowly pushes in as she lowers the umbrella, turns toward the approaching bus, and by the final second the frame matches Picture 2 exactly, with her hand raised to hail the bus.

overall_soundscape: Steady rain on pavement and umbrella fabric, distant traffic, soft footsteps on wet concrete, the low hiss of bus brakes.

non_diegetic_music: Sparse piano notes at a slow tempo that gradually thin out and disappear.
```

## Example 4 — Dialogue + voiceover + cross-cut continuity

```
integrated_multimodal_description: [Shot 1] Cinematic, medium shot. A middle-aged man in a grey coat (S1) stands on a foggy bridge at night, looking at the river. He says in an off-screen voiceover: <d>[English] I still remember that road.</d> while his lips remain completely closed. [Shot 2] At 00:04.200, the camera cuts to a close-up of his face as the same voiceover continues seamlessly across the cut: <d>[English] Every turn felt longer than the last.</d> His lips stay closed.

overall_soundscape: Low river current, distant city hum, occasional soft wind against the bridge cables.

non_diegetic_music: Sustained low strings with a single, sparse piano note every few seconds.
```

## Camera motion quick reference

| Need | Preferred phrasing |
|------|--------------------|
| Subtle approach | The camera pushes in with small amplitude at slow speed |
| Dramatic reveal | The camera pans right with large amplitude at fast speed, revealing... |
| Follow subject | The camera performs a tracking shot, following the runner |
| Hold still | The camera holds a static shot |
| Impact | The camera shakes strongly as the explosion hits |

Always embed the motion inside the shot description as a natural action, never as a trailing label list.
