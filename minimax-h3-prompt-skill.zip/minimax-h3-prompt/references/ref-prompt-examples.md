# Full-Reference (Ref2VA) Prompt Examples

## Example structure skeleton

```
subject_definitions:
<Subject 1> is the young man with short wavy blonde hair, wearing a bright pink suit jacket, matching pink trousers, an unbuttoned white shirt, and silver rings, holding a small black lamb in his arms in <Video 1>.
<Video 1> is the source video for the editing task.
<Audio 1> is the synchronized audio track of <Video 1>, providing the background music.
<Audio 2> is the voice timbre reference for <Subject 1>'s voice, containing a spoken male voiceover.

summary:
[video editing + audio reference + audio reuse] The target video is an edited version of <Video 1>. <Subject 1>, wearing a bright pink suit and holding a black lamb, stands in a grassy field with other white lambs in the background. The edit animates <Subject 1>'s face to speak the user-provided dialogue. <Audio 1> is partially reused while <Audio 2> supplies the new speaking voice.

retention_analysis:
<Subject 1> (appears throughout): partially_preserved - appearance and clothing fully preserved; facial animation added for new dialogue.
<Video 1> (source structure and background): fully_preserved - environment, lighting, and camera framing retained.
<Audio 1>: partially_copy - background music retained, original voice removed.
<Audio 2>: reference - used only for voice timbre and delivery style of the new dialogue.

detailed_description:
[Shot 1] Live-action. The camera holds the same medium shot as <Video 1>. <Subject 1> stands in the grassy field holding the black lamb, now speaking the new line with lip movements synchronized to the dialogue delivered in the timbre of <Audio 2>: <d>[English] This little one found me first.</d> Background lambs continue grazing under soft daylight. The original camera framing and lighting of <Video 1> remain unchanged.

overall_soundscape: Soft wind through grass, distant sheep bleats, subtle fabric movement of the pink suit.

non_diegetic_music: N/A
```

## Label usage rules (quick)

- Use `<Subject N>` for any reusable visual content that will appear or be modified.
- Use standalone `<Picture N>` only when the image itself is a concrete frame anchor or storyboard.
- Use `<Video N>` for edit / continuation / temporal-structure sources.
- Use `<Audio N>` for any audio that is copied or referenced; number independently of video.
- Keep the same label meaning across all six sections.

## Task-type prefix examples

| Situation | Prefix |
|-----------|--------|
| Pure character/style/action reference | `[reference generation]` |
| Image used as first/last/key frame | `[keyframe completion]` |
| Directly edit an existing video | `[video editing]` |
| Continue after an existing video | `[video continuation]` |
| Copy original audio (full or part) | `+ audio reuse` |
| Only timbre / style / rhythm from audio | `+ audio reference` |
| Edit video + keep its music + new dialogue from another voice | `[video editing + audio reuse + audio reference]` |

## Retention markers

**Visual**: fully_preserved · partially_preserved · attribute_transfer · weak_reference  
**Audio**: fully_copy · partially_copy · reference · weak_reference

Always state where the content appears (shot numbers) and what exactly is kept or changed.
